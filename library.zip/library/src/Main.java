import view.Initial;

public class Main {
    public static void main(String[] args)
    {
    	new Initial().setVisible(true);
    }
}